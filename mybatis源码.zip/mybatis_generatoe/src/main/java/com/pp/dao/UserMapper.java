package com.pp.dao;

import com.pp.domain.User;
import java.util.List;

public interface UserMapper {
    int insert(User record);

    List<User> selectAll();
}