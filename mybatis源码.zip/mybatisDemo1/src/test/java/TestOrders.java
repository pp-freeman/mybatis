import com.pp.mybatis.dao.OrdersMapper;
import com.pp.mybatis.pojo.OrderExt;
import com.pp.mybatis.pojo.Orders;
import com.pp.mybatis.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

public class TestOrders {
    private SqlSessionFactory sqlSessionFactory;
    @Before
    public void setUp() throws Exception {
        String resource = "sqlMapConfig.xml"; //全局配置文件的路径
        //读取配置文件
        InputStream in = Resources.getResourceAsStream(resource);
        //创建SqlSessionFactory
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
    }

    @Test
    public void findOrdersAndUserTest(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrdersMapper mapper = sqlSession.getMapper(OrdersMapper.class);
        List<OrderExt> list = mapper.findOrdersAndUser();
        System.out.println(list);
    }


    @Test
    public void findOrdersAndUserTest1(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrdersMapper mapper = sqlSession.getMapper(OrdersMapper.class);
        List<OrderExt> list = mapper.findOrdersAndUser1();
        System.out.println(list);
    }

    @Test
    public void findOrdersAndDetailRstMapTest(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrdersMapper mapper = sqlSession.getMapper(OrdersMapper.class);
        List<OrderExt> list = mapper.findOrdersAndDetailRstMap();
        System.out.println(list);
    }

    @Test
    public void findUserAndItemsRstMapTest(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrdersMapper mapper = sqlSession.getMapper(OrdersMapper.class);
        List<User> list = mapper.findUserAndItemsRstMap();
        System.out.println(list);
    }

    @Test
    public void  findOrderAndUserLazyLoadingTest(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        OrdersMapper mapper = sqlSession.getMapper(OrdersMapper.class);
        List<OrderExt> list = mapper.findOrderAndUserLazyLoading();
        System.out.println(list);
    }



}
