import com.pp.mybatis.dao.OrdersMapper;
import com.pp.mybatis.dao.UserDao;
import com.pp.mybatis.dao.UserMapper;
import com.pp.mybatis.dao.impl.UserDaoImpl;
import com.pp.mybatis.pojo.User;
import com.pp.mybatis.pojo.UserQueryOV;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class testMapper {
    private SqlSessionFactory sqlSessionFactory;

    @Before
    public void setUp() throws Exception {
        String resource = "sqlMapConfig.xml"; //全局配置文件的路径
        //读取配置文件
        InputStream in = Resources.getResourceAsStream(resource);
        //创建SqlSessionFactory
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
    }

    @Test
    public void findUserByIdDaoTest() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //由mybatis通过sqlsession来创建代理对象
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        User user = userMapper.findUserById(1);
        System.out.println(user);
        sqlSession.close();
    }

    @Test
    public void testOneLevelCache(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //由mybatis通过sqlsession来创建代理对象
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        //第一次查询
        User user1 = userMapper.findUserRstMap(1);
        System.out.println(user1);
        sqlSession.clearCache();
        //第二次查询
        User user2 = userMapper.findUserRstMap(1);
        System.out.println(user2);

        sqlSession.close();
    }

    @Test
    public void testTwoLevelCache() throws Exception {
        SqlSession sqlSession1 = sqlSessionFactory.openSession();
        SqlSession sqlSession2 = sqlSessionFactory.openSession();
        SqlSession sqlSession3 = sqlSessionFactory.openSession();
        UserMapper mapper1 = sqlSession1.getMapper(UserMapper.class);
        UserMapper mapper2 = sqlSession2.getMapper(UserMapper.class);
        UserMapper mapper3 = sqlSession3.getMapper(UserMapper.class);

        //第一次查询
        User user1 = mapper1.findUserById(1);
        System.out.println(user1);
        sqlSession1.close();
        //在close的时候才会将数据写入到二级缓存中
        //第二次查询
        User user2 = mapper2.findUserById(1);
        System.out.println(user2);
        //第三次查询
        User user3 = mapper3.findUserById(1);
        System.out.println(user3);

        sqlSession2.close();
        sqlSession3.close();
    }

    @Test
    public void findUserByNameTest() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        List<User> list = userMapper.findUserByName("小明");
        System.out.println(list);
        sqlSession.close();
    }

    @Test
    public void insertUserTest() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        User user = new User();
        user.setUsername("张三");
        user.setAddress("德阳中江");
        userMapper.insertUser(user);
        sqlSession.commit();
        sqlSession.close();
    }

    @Test
    public void findUserListTest() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //由mybatis通过sqlsession来创建代理对象
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        UserQueryOV ov = new UserQueryOV();
        User user = new User();
        user.setUsername("小明");
        user.setSex("1");
        ov.setUser(user);
        List<User> list = userMapper.findUserList(ov);
        System.out.println(list);
        sqlSession.close();
    }


    @Test
    public void findUserCountTest() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //由mybatis通过sqlsession来创建代理对象
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        UserQueryOV ov = new UserQueryOV();
        User user = new User();
        user.setUsername("小明");
        user.setSex("1");
        ov.setUser(user);
        int num = userMapper.findUserCount(ov);
        System.out.println(num);
        sqlSession.close();
    }

    @Test
    public void findUserRstMapTest() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //由mybatis通过sqlsession来创建代理对象
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        UserQueryOV ov = new UserQueryOV();
        User user = userMapper.findUserRstMap(1);
        System.out.println(user);
        sqlSession.close();
    }

    @Test
    public void findUserByName1Test() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //由mybatis通过sqlsession来创建代理对象
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        UserQueryOV ov = new UserQueryOV();
        User user = new User();
        user.setUsername("小明");
        user.setSex("1");
        ov.setUser(user);
        List<User> list = userMapper.findUserByName1(ov);
        System.out.println(list);
        sqlSession.close();
    }

    @Test
    public void findUserCountTest1() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //由mybatis通过sqlsession来创建代理对象
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        UserQueryOV ov = new UserQueryOV();
        User user = new User();
//        user.setUsername("小明");
        user.setSex("1");
        ov.setUser(user);
        int num = userMapper.findUserCount1(ov);
        System.out.println(num);
        sqlSession.close();
    }


    @Test
    public void findUserByNameListTest() throws Exception {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //由mybatis通过sqlsession来创建代理对象
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        UserQueryOV ov = new UserQueryOV();
        List<Integer> idList = new ArrayList<>();
        idList.add(10);
        idList.add(16);
        idList.add(22);
        ov.setIdList(idList);
        List<User> list = userMapper.findUserByIdList(ov);
        System.out.println(list);
        sqlSession.close();
    }
}
