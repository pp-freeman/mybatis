import com.pp.mybatis.dao.UserDao;
import com.pp.mybatis.dao.impl.UserDaoImpl;
import com.pp.mybatis.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class testDao {

    private SqlSessionFactory sqlSessionFactory;

    @Before
    public void setUp() throws Exception {
        String resource = "sqlMapConfig.xml"; //全局配置文件的路径
        //读取配置文件
        InputStream in = Resources.getResourceAsStream(resource);
        //创建SqlSessionFactory
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
    }

    @Test
    public void findUserByIdDaoTest() throws Exception {
        //创建UserDao
        UserDao userDao = new UserDaoImpl(sqlSessionFactory);
        User user = userDao.findUserById(1);
        System.out.println(user);
    }

    @Test
    public void findUserByNameDaoTest() throws Exception {
        //创建UserDao
        UserDao userDao = new UserDaoImpl(sqlSessionFactory);
        List<User> list = userDao.findUserByName("小明");
        System.out.println(list);
    }

    @Test
    public void insertUserDaoTest() throws Exception {
        UserDao userDao = new UserDaoImpl(sqlSessionFactory);
        User user = new User();
        user.setUsername("张三");
        user.setAddress("德阳中江");
        userDao.insertUser(user);
    }
}
