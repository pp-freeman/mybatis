package com.pp.mybatis.pojo;

import java.util.List;

public class OrderExt extends Orders {
    private String username;
    private String sex;

    //用户信息
    private User user;

    //订单明细信息
    private List<Orderdetail> orderdetailList;

    public void setOrderdetailList(List<Orderdetail> orderdetailList) {
        this.orderdetailList = orderdetailList;
    }

    public List<Orderdetail> getOrderdetailList() {
        return orderdetailList;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getUsername() {
        return username;
    }

    public String getSex() {
        return sex;
    }

    @Override
    public String toString() {
        return "OrderExt{" +
                super.toString()+
                "username='" + username + '\'' +
                ", sex='" + sex + '\'' +
                ", user=" + user +
                ", orderdetailList=" + orderdetailList +
                '}';
    }
}
