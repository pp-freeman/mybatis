package com.pp.mybatis.pojo;

import java.util.List;

public class UserQueryOV {
    //用户信息
    private User user;
    //商品id集合
    private List<Integer> idList;
    //商品信息

    //订单信息


    public void setIdList(List<Integer> idList) {
        this.idList = idList;
    }

    public List<Integer> getIdList() {
        return idList;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }
}
