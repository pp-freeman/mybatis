package com.pp.mybatis.dao.impl;

import com.pp.mybatis.dao.UserDao;
import com.pp.mybatis.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;


public class UserDaoImpl implements UserDao {

    //依赖注入
    private SqlSessionFactory sqlSessionFactory;
    public UserDaoImpl(SqlSessionFactory sqlSessionFactory){
        this.sqlSessionFactory = sqlSessionFactory;
    }

    @Override
    public User findUserById(int id) throws IOException {
        //创建sqlSession
        SqlSession sqlSession = sqlSessionFactory.openSession();
        User user = sqlSession.selectOne("test.findUserById",id);
        //关闭资源
        sqlSession.close();
        return user;
    }

    @Override
    public List<User> findUserByName(String name) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //调用方法
        //第一个参数:表示statement的唯一标识
        List<User> list = sqlSession.selectList("test.findUserByName",name);

        //关闭资源
        sqlSession.close();
        return list;
    }

    @Override
    public void insertUser(User user) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //调用方法
        //第一个参数:表示statement的唯一标识
        sqlSession.insert("test.insertUser",user);
        //提交事务
        sqlSession.commit();
        //关闭资源
        sqlSession.close();
    }
}
