package com.pp.mybatis.dao;

import com.pp.mybatis.pojo.OrderExt;
import com.pp.mybatis.pojo.Orders;
import com.pp.mybatis.pojo.User;

import java.util.List;

public interface OrdersMapper {
    //查询订单和用户
    public List<OrderExt> findOrdersAndUser();
    public List<OrderExt> findOrdersAndUser1();
    //查询订单和用户和商品
    public List<OrderExt> findOrdersAndDetailRstMap();
    //查询用户和商品信息
    public List<User> findUserAndItemsRstMap();
    //延迟加载
    public List<OrderExt> findOrderAndUserLazyLoading();
}
