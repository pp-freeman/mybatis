package com.pp.mybatis.dao;

import com.pp.mybatis.pojo.User;
import com.pp.mybatis.pojo.UserQueryOV;

import java.util.List;

public interface UserMapper {
    //根据用户id查询用户信息
    public User findUserById(int id) throws Exception;
    //根据用户名模糊查询用户列表
    public List<User> findUserByName(String name) throws Exception;
    //添加用户
    public void insertUser(User user) throws Exception;
    //联表查询
    public List<User> findUserList(UserQueryOV ov);
    //综合查询用户总数
    public int findUserCount(UserQueryOV ov);
    //resultMap入门
    public User findUserRstMap(int id);
    //动态sql
    public List<User> findUserByName1(UserQueryOV ov);
    //sql片段
    public int findUserCount1(UserQueryOV ov);
    //foreach
    public  List<User> findUserByIdList(UserQueryOV ov);
}
